import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const script = path.resolve('scripts/apply-mobile-branding.py');
async function fixture() {
  const root = await mkdtemp(path.join(os.tmpdir(), 'tropical-mobile-fixture-'));
  await mkdir(path.join(root, 'android/app/src/main/res/values'), { recursive: true });
  await mkdir(path.join(root, 'app/lib/constants'), { recursive: true });
  await writeFile(path.join(root, 'app.json'), JSON.stringify({ name: 'RocketChatRN', server: 'https://open.rocket.chat' }, null, 2) + '\n');
  await writeFile(path.join(root, 'android/gradle.properties'), 'org.gradle.jvmargs=-Xmx4g\nAPPLICATION_ID=chat.rocket.reactnative\nVERSIONCODE=1\nBugsnagAPIKey=""\n');
  await writeFile(path.join(root, 'android/app/src/main/AndroidManifest.xml'), '<manifest android:sharedUserId="chat.rocket.android">\n</manifest>\n');
  await writeFile(path.join(root, 'android/app/src/main/res/values/strings.xml'), '<resources>\n    <string name="app_name">Rocket.Chat</string>\n    <string name="share_extension_name">Rocket.Chat</string>\n</resources>\n');
  const colorLines = [];
  for (const palette of ['light', 'dark']) {
    colorLines.push(`const ${palette} = {`);
    colorLines.push("  buttonBackgroundPrimaryDefault: '#156FF5',");
    colorLines.push("  buttonBackgroundPrimaryPress: '#10529E',");
    colorLines.push("  buttonBackgroundPrimaryDisabled: '#D1EBFE',");
    colorLines.push('};');
  }
  await writeFile(path.join(root, 'app/lib/constants/colors.ts'), colorLines.join('\n') + '\n');
  return root;
}

test('mobile branding script updates only verified white-label settings', async () => {
  const root = await fixture();
  try {
    const result = spawnSync('python3', [script, '--repo', root, '--server-url', 'https://chat.example.com'], { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
    assert.deepEqual(JSON.parse(await readFile(path.join(root, 'app.json'), 'utf8')), { name: 'TropicalChat', server: 'https://chat.example.com' });
    assert.match(await readFile(path.join(root, 'android/gradle.properties'), 'utf8'), /APPLICATION_ID=com\.tropicalservers\.chat/);
    assert.match(await readFile(path.join(root, 'android/app/src/main/AndroidManifest.xml'), 'utf8'), /android:sharedUserId="com\.tropicalservers\.chat"/);
    assert.match(await readFile(path.join(root, 'android/app/src/main/res/values/strings.xml'), 'utf8'), /name="app_name">Tropical Chat</);
    const colors = await readFile(path.join(root, 'app/lib/constants/colors.ts'), 'utf8');
    assert.equal((colors.match(/buttonBackgroundPrimaryDefault: '#14b8a6'/g) ?? []).length, 2);
    assert.equal((colors.match(/buttonBackgroundPrimaryPress: '#0f766e'/g) ?? []).length, 2);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('mobile branding script refuses remote HTTP and makes no changes', async () => {
  const root = await fixture();
  try {
    const before = await readFile(path.join(root, 'app.json'), 'utf8');
    const result = spawnSync('python3', [script, '--repo', root, '--server-url', 'http://chat.example.com'], { encoding: 'utf8' });
    assert.equal(result.status, 2);
    assert.equal(await readFile(path.join(root, 'app.json'), 'utf8'), before);
  } finally { await rm(root, { recursive: true, force: true }); }
});
