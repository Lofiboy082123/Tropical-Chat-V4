import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const script = path.resolve('desktop/generate-config.mjs');

test('writes official Electron servers.json for HTTPS server', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'tropical-chat-test-'));
  try {
    const out = path.join(dir, 'servers.json');
    const result = spawnSync(process.execPath, [script, out], {
      env: { ...process.env, TROPICAL_CHAT_SERVER_URL: 'https://chat.example.com' },
      encoding: 'utf8'
    });
    assert.equal(result.status, 0, result.stderr);
    assert.deepEqual(JSON.parse(await readFile(out, 'utf8')), { 'Tropical Chat': 'https://chat.example.com' });
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('rejects non-HTTPS remote server', () => {
  const result = spawnSync(process.execPath, [script, '/tmp/tropical-chat-invalid-servers.json'], {
    env: { ...process.env, TROPICAL_CHAT_SERVER_URL: 'http://chat.example.com' },
    encoding: 'utf8'
  });
  assert.equal(result.status, 2);
  assert.match(result.stderr, /must use HTTPS/);
});

test('rejects missing server URL', () => {
  const env = { ...process.env };
  delete env.TROPICAL_CHAT_SERVER_URL;
  const result = spawnSync(process.execPath, [script, '/tmp/tropical-chat-missing-servers.json'], { env, encoding: 'utf8' });
  assert.equal(result.status, 2);
  assert.match(result.stderr, /set TROPICAL_CHAT_SERVER_URL/);
});
