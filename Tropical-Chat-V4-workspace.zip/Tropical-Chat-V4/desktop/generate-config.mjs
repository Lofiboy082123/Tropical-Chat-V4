#!/usr/bin/env node
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

const serverUrl = process.env.TROPICAL_CHAT_SERVER_URL;
const output = process.argv[2] ?? path.resolve('servers.json');
if (!serverUrl) {
  console.error('ERROR: set TROPICAL_CHAT_SERVER_URL to your real Rocket.Chat HTTPS URL.');
  process.exit(2);
}
let parsed;
try { parsed = new URL(serverUrl); } catch {
  console.error('ERROR: TROPICAL_CHAT_SERVER_URL must be a valid absolute URL.');
  process.exit(2);
}
if (parsed.protocol !== 'https:' && parsed.hostname !== 'localhost' && parsed.hostname !== '127.0.0.1') {
  console.error('ERROR: non-local server URLs must use HTTPS.');
  process.exit(2);
}
const config = { 'Tropical Chat': parsed.toString().replace(/\/$/, '') };
await mkdir(path.dirname(path.resolve(output)), { recursive: true });
await writeFile(output, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o644 });
console.log(`Wrote ${path.resolve(output)} for the official Rocket.Chat Electron servers.json mechanism.`);
