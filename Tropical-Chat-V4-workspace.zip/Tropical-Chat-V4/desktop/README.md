# Desktop white-label configuration

The official Rocket.Chat Electron app supports a bundled `servers.json` to seed the server list and skip the server-picker screen on first launch. This workspace includes `generate-config.mjs` to create that file from an explicitly supplied real URL; it intentionally does not invent a production hostname.

```bash
TROPICAL_CHAT_SERVER_URL=https://chat.example.com node desktop/generate-config.mjs /path/to/Rocket.Chat.Electron/servers.json
```

Replace `chat.example.com` with Tropical Servers' actual configured domain. The official desktop source repository is not present in this workspace yet, so this configuration helper does not claim to have changed Electron's app name, icons, or Starlight notification title. Those changes must be made and tested in the upstream source checkout.

Upstream desktop build requirements documented by Rocket.Chat at the time of research: Node.js >= 24.11.1 and Yarn >= 4.0.2. The current environment has Node.js 22.16.0, no Yarn executable, and no network access to clone GitHub; it cannot build the current upstream desktop source here.
