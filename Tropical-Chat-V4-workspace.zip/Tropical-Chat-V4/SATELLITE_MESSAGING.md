# Tropical Chat satellite messaging: feasibility and integration plan

Research date: 2026-10-25. This is an integration assessment, not a claim that satellite messaging is implemented.

## Findings

- Android's public `SatelliteManager` API was added at API level 36 (Android 16). It manages satellite state and operations such as provisioning, pointing, messaging, and location sharing, but is intended for devices exposing `PackageManager.FEATURE_TELEPHONY_SATELLITE`; behavior on unsupported devices is not reliable.
- Android documents constrained satellite networks separately. Applications do not use constrained satellite networks by default; apps can opt in to satellite-optimized networking and should reduce bandwidth, batch network operations, and account for high latency. Android documents a `bandwidth_constrained_ok` option for FCM delivery over constrained networks when the app and server have been deliberately adapted.
- These platform APIs do not by themselves grant every third-party app arbitrary access to a carrier's satellite SMS service. Availability depends on the device/modem/firmware, Android build, carrier, satellite provider, supported region, plan, provisioning, and any provider-specific authorization/API.
- Rocket.Chat's normal mobile client exchanges messages with a Rocket.Chat server over IP. This project has not implemented a satellite transport, a direct SMS gateway, or an integration with a Samsung/carrier satellite provider.

## Safe future design

1. Keep the ordinary Rocket.Chat WebSocket/HTTP path unchanged and fully functional.
2. Detect actual device support and active satellite network capabilities using public Android APIs only when the final minimum/target SDK and device matrix are known.
3. First evaluate whether the ordinary Rocket.Chat transport can use a constrained IP network with conservative retries, batching, reduced attachments, and backpressure. Do not assume the satellite network exposes a general-purpose IP path.
4. If a provider offers an authorized message API or carrier gateway, implement a separately isolated transport adapter with explicit user consent, clear delivery states, idempotency keys, message ordering rules, and end-to-end security review. Avoid silently routing private chat content to a third party.
5. Test with the exact Samsung models, regional firmware, carriers, provider plans, and physical satellite coverage. Emulator-only checks cannot prove satellite service.

## Information required before implementation

- Exact Samsung model numbers and Android/One UI versions.
- Country/region and carrier.
- Satellite service/provider and plan name.
- Whether the intended service is carrier satellite SMS, satellite data/IP, or a vendor-specific API.
- Developer documentation and authorization for the selected provider.

## References

- Android `SatelliteManager` API: https://developer.android.com/reference/android/telephony/satellite/SatelliteManager
- Android guidance for constrained satellite networks: https://developer.android.com/develop/connectivity/satellite/constrained-networks
- Rocket.Chat mobile client: https://github.com/RocketChat/Rocket.Chat.ReactNative

## Status

No satellite transport code has been written. No target Samsung device, carrier account, satellite plan, provider API credentials, or physical satellite test environment was available in the inspected workspace.
