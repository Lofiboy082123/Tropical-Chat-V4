# Tropical Chat V4

**Tropical Servers · Secure. Reliable. Tropical.**

Tropical Chat V4 is intended to be a white-label customization of the official Rocket.Chat mobile and Electron clients with the official Rocket.Chat server. This workspace preserves the supplied Tropical Chat V3 ZIP separately; it is not a replacement for V3.

## Current workspace status

The workspace initially contained an empty `Tropical-Chat-V4/` directory, not a Git checkout of either official client. The V3 ZIP is a small separate reference project. This workspace therefore cannot truthfully claim prior Android source changes or a successful Gradle build. Outbound DNS/network access to GitHub failed during initial inspection, and this environment has no Android SDK, Gradle executable, Docker, or Podman installed.

The first independent implementation here is the deployment bootstrap around Rocket.Chat's **official `rocketchat-compose` repository**, a version-pinned local deployment profile, original SVG brand assets, desktop default-server configuration generation, and satellite-network research. The upstream Android and Electron source customizations remain blocked until the official repositories can be fetched into this workspace.

## Repository layout

- `branding/` — original scalable Tropical Chat app mark and splash art, rasterized Android PNG sizes, desktop PNG, and Windows ICO. Rebuild raster assets with `python3 scripts/build-brand-assets.py` (requires CairoSVG and Pillow).
- `server/` — secure example environment, version-pinned Compose override, bootstrap/deploy/backup/restore helpers.
- `desktop/` — generator for the official Electron client's supported `servers.json` mechanism.
- `docs/` — reproducible setup and status documentation.
- `dist/` — reserved for artifacts that are actually built; no fake APK or installer is included.
- `SATELLITE_MESSAGING.md` — verified platform research and future integration constraints.

## Quick start (after installing Docker Compose v2)

1. Copy `server/.env.example` to `server/.env` and review every value.
2. Run `bash server/deploy.sh --local` to fetch the official compose repository and start a local-only Rocket.Chat stack.
3. Open `http://localhost:3000` and complete the official first-run administrator setup.

This requires network access to GitHub and the container registry. Do not expose a local deployment to the internet; configure a domain, HTTPS reverse proxy, firewall, backups, and secrets first. Full steps are in `docs/SERVER_DEPLOYMENT.md`.

## Branding palette

- Deep navy `#0b1220`
- Charcoal `#111827`
- Tropical teal `#14b8a6`
- Palm green `#22c55e`

## Upstream sources

- [Rocket.Chat React Native](https://github.com/RocketChat/Rocket.Chat.ReactNative)
- [Rocket.Chat Electron](https://github.com/RocketChat/Rocket.Chat.Electron)
- [Official Rocket.Chat Compose](https://github.com/RocketChat/rocketchat-compose)
- [Official Docker deployment documentation](https://docs.rocket.chat/docs/deploy-with-docker-docker-compose)

See `docs/BUILD_STATUS.md` for exactly what has and has not been verified in this workspace.
