#!/usr/bin/env python3
"""Apply reviewed Tropical Chat white-label settings to an official Rocket.Chat RN checkout.

Targets are based on Rocket.Chat's official single-server white-label guide. The script
validates every expected upstream file/setting before writing anything, and requires the
real server URL rather than inventing a hostname.
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from urllib.parse import urlparse

APP_ID = "com.tropicalservers.chat"
APP_NAME = "Tropical Chat"
COLORS = {
    "buttonBackgroundPrimaryDefault": "#14b8a6",
    "buttonBackgroundPrimaryPress": "#0f766e",
    "buttonBackgroundPrimaryDisabled": "#ccfbf1",
}


def replace_single(pattern: str, replacement: str, content: str, label: str, flags: int = 0) -> str:
    updated, count = re.subn(pattern, replacement, content, count=1, flags=flags)
    if count != 1:
        raise ValueError(f"Expected exactly one {label} match; found {count}. No files written.")
    return updated


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True, help="Path to official Rocket.Chat.ReactNative checkout")
    parser.add_argument("--server-url", required=True, help="Real Rocket.Chat workspace URL (HTTPS except localhost)")
    parser.add_argument("--dry-run", action="store_true", help="Validate and show intended changes without writing files")
    args = parser.parse_args()
    root = args.repo.resolve()
    parsed = urlparse(args.server_url)
    if parsed.scheme not in {"https", "http"} or not parsed.netloc:
        parser.error("--server-url must be an absolute HTTP(S) URL")
    if parsed.scheme != "https" and parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
        parser.error("remote server URLs must use HTTPS")
    server_url = args.server_url.rstrip("/")

    paths = {
        "app.json": root / "app.json",
        "gradle.properties": root / "android/gradle.properties",
        "manifest": root / "android/app/src/main/AndroidManifest.xml",
        "strings": root / "android/app/src/main/res/values/strings.xml",
        "colors": root / "app/lib/constants/colors.ts",
    }
    missing = [str(p.relative_to(root)) for p in paths.values() if not p.is_file()]
    if missing:
        parser.error("Expected official white-label files missing: " + ", ".join(missing))

    # Stage all file contents in memory first; no partial writes if any validation fails.
    staged: dict[Path, str] = {}
    app = json.loads(paths["app.json"].read_text(encoding="utf-8"))
    if not isinstance(app, dict) or "name" not in app or "server" not in app:
        parser.error("app.json does not have the documented 'name' and 'server' keys")
    app["name"] = "TropicalChat"
    app["server"] = server_url
    staged[paths["app.json"]] = json.dumps(app, indent=2, ensure_ascii=False) + "\n"

    gradle = paths["gradle.properties"].read_text(encoding="utf-8")
    staged[paths["gradle.properties"]] = replace_single(
        r"(?m)^APPLICATION_ID=.*$", f"APPLICATION_ID={APP_ID}", gradle, "APPLICATION_ID property"
    )

    manifest = paths["manifest"].read_text(encoding="utf-8")
    staged[paths["manifest"]] = replace_single(
        r'android:sharedUserId="[^"]+"', f'android:sharedUserId="{APP_ID}"', manifest, "android:sharedUserId"
    )

    strings = paths["strings"].read_text(encoding="utf-8")
    for key in ("app_name", "share_extension_name"):
        strings = replace_single(
            rf'(<string\s+name="{re.escape(key)}">)[^<]*(</string>)',
            rf"\g<1>{APP_NAME}\g<2>", strings, f"{key} string"
        )
    staged[paths["strings"]] = strings

    colors = paths["colors"].read_text(encoding="utf-8")
    for key, color in COLORS.items():
        pattern = rf"(?m)^([ \t]*{re.escape(key)}:[ \t]*)['\"]#[0-9A-Fa-f]{{6}}['\"]([ \t]*,?[ \t]*)$"
        colors, count = re.subn(pattern, lambda m: f"{m.group(1)}'{color}'{m.group(2)}", colors)
        if count != 2:
            raise ValueError(f"Expected {key} in both light and dark palettes (2 matches); found {count}. No files written.")
    staged[paths["colors"]] = colors

    for path, content in staged.items():
        print(f"{'WOULD UPDATE' if args.dry_run else 'UPDATE'} {path.relative_to(root)}")
        if not args.dry_run:
            path.write_text(content, encoding="utf-8")
    if args.dry_run:
        print("Dry run only; no upstream files changed.")
    else:
        print(f"Applied Tropical Chat branding to official source. Application ID: {APP_ID}; server: {server_url}")
        print("Icon and splash resources must still be copied into the exact resource locations after inspecting this branch's asset layout.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise SystemExit(f"ERROR: {exc}")
