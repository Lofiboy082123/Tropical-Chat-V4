#!/usr/bin/env python3
"""Rasterize original Tropical Chat SVG branding into common platform assets."""
from pathlib import Path
import cairosvg
from PIL import Image
import io

ROOT = Path(__file__).resolve().parents[1]
BRANDING = ROOT / "branding"
MARK = BRANDING / "tropical-chat-mark.svg"
SPLASH = BRANDING / "tropical-chat-splash.svg"

def render_png(source: Path, output: Path, width: int, height: int | None = None) -> Image.Image:
    png = cairosvg.svg2png(url=str(source), output_width=width, output_height=height)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(png)
    return Image.open(io.BytesIO(png)).convert("RGBA")

for size in (48, 72, 96, 144, 192, 512):
    render_png(MARK, BRANDING / "android" / f"ic_launcher_{size}.png", size)

# Common single-file Android adaptive-icon foreground/background reference (full artwork icon).
render_png(MARK, BRANDING / "android" / "ic_launcher.png", 512)
render_png(SPLASH, BRANDING / "android" / "splash.png", 1080, 1920)
render_png(MARK, BRANDING / "desktop" / "tropical-chat.png", 512)
icon = Image.open(BRANDING / "desktop" / "tropical-chat.png").convert("RGBA")
icon.save(BRANDING / "desktop" / "tropical-chat.ico", format="ICO", sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])

for path in sorted([* (BRANDING / "android").glob("*.png"), *(BRANDING / "desktop").glob("*.png"), *(BRANDING / "desktop").glob("*.ico")]):
    with Image.open(path) as image:
        image.verify()
    print(f"OK {path.relative_to(ROOT)} ({path.stat().st_size} bytes)")
