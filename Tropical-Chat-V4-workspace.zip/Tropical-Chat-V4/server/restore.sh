#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $# -ne 1 || ! -f "$1" ]]; then echo 'Usage: bash server/restore.sh /path/to/backup.archive' >&2; exit 2; fi
ARCHIVE="$(cd -- "$(dirname -- "$1")" && pwd)/$(basename -- "$1")"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
UPSTREAM_DIR="$ROOT_DIR/server/upstream/rocketchat-compose"
ENV_FILE="$ROOT_DIR/server/.env"
[[ -d "$UPSTREAM_DIR/.git" && -f "$ENV_FILE" ]] || { echo 'ERROR: deployment is not initialized.' >&2; exit 2; }
cd "$UPSTREAM_DIR"
CID="$(docker compose --env-file "$ENV_FILE" -f compose.database.yml -f compose.yml -f compose.nats.yml -f docker.yml -f "$ROOT_DIR/server/compose.override.yml" ps -q mongodb)"
[[ -n "$CID" ]] || { echo 'ERROR: MongoDB service is not running.' >&2; exit 3; }
echo 'WARNING: this restore merges data into the target database and can overwrite documents. Confirm you have a separate tested backup.'
read -r -p 'Type RESTORE to continue: ' CONFIRM
[[ "$CONFIRM" == RESTORE ]] || { echo 'Cancelled.'; exit 4; }
docker exec -i "$CID" sh -lc 'mongorestore --drop --archive' < "$ARCHIVE"
echo 'Restore command completed. Verify application logs and test accounts/messages before returning to service.'
