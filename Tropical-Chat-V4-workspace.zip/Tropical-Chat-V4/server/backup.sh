#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
UPSTREAM_DIR="$ROOT_DIR/server/upstream/rocketchat-compose"
ENV_FILE="$ROOT_DIR/server/.env"
OUT_DIR="${1:-$ROOT_DIR/server/backups}"
[[ -d "$UPSTREAM_DIR/.git" ]] || { echo 'ERROR: official compose repository is not initialized; run server/deploy.sh first.' >&2; exit 2; }
[[ -f "$ENV_FILE" ]] || { echo 'ERROR: server/.env is missing.' >&2; exit 2; }
command -v docker >/dev/null 2>&1 || { echo 'ERROR: Docker CLI is required.' >&2; exit 2; }
mkdir -p "$OUT_DIR"; chmod 700 "$OUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
cd "$UPSTREAM_DIR"
# Match the default/local stack's service set. Use mongodump inside the actual Mongo container.
CID="$(docker compose --env-file "$ENV_FILE" -f compose.database.yml -f compose.yml -f compose.nats.yml -f docker.yml -f "$ROOT_DIR/server/compose.override.yml" ps -q mongodb)"
[[ -n "$CID" ]] || { echo 'ERROR: MongoDB service is not running.' >&2; exit 3; }
docker exec "$CID" sh -lc 'mongodump --archive' > "$OUT_DIR/tropical-chat-$STAMP.archive"
test -s "$OUT_DIR/tropical-chat-$STAMP.archive"
chmod 600 "$OUT_DIR/tropical-chat-$STAMP.archive"
echo "MongoDB archive created: $OUT_DIR/tropical-chat-$STAMP.archive"
echo 'Copy the archive off-host and test restoration into a separate MongoDB instance regularly.'
