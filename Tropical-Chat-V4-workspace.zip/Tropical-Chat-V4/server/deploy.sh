#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_DIR="$ROOT_DIR/server"
UPSTREAM_DIR="$SERVER_DIR/upstream/rocketchat-compose"
ENV_FILE="$SERVER_DIR/.env"
UPSTREAM_URL="https://github.com/RocketChat/rocketchat-compose.git"
PROFILE="local"

usage() {
  cat <<'USAGE'
Usage: bash server/deploy.sh [--local] [--production]

  --local       Bind Rocket.Chat to 127.0.0.1:3000; intended for local setup/testing.
  --production  Refuse localhost settings and use the official Traefik stack files.

Requires Git and Docker Compose v2. Copies server/.env.example to server/.env if missing.
Review the generated .env before continuing. This script never creates an admin user or password.
USAGE
}
for arg in "$@"; do
  case "$arg" in
    --local) PROFILE=local ;;
    --production) PROFILE=production ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $arg" >&2; usage >&2; exit 2 ;;
  esac
done

command -v git >/dev/null 2>&1 || { echo 'ERROR: git is required.' >&2; exit 10; }
command -v docker >/dev/null 2>&1 || { echo 'ERROR: Docker CLI is missing. Install Docker Engine and Compose v2.' >&2; exit 11; }
docker compose version >/dev/null 2>&1 || { echo 'ERROR: Docker Compose v2 plugin is unavailable (docker compose version failed).' >&2; exit 12; }

if [[ ! -f "$ENV_FILE" ]]; then
  cp "$SERVER_DIR/.env.example" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  echo "Created $ENV_FILE; review it before deployment."
fi

# Parse only known settings without sourcing shell syntax from a user-controlled env file.
get_env() { sed -n "s/^$1=//p" "$ENV_FILE" | tail -n 1; }
ROOT_URL="$(get_env ROOT_URL)"
if [[ "$PROFILE" == production ]]; then
  DOMAIN="$(get_env DOMAIN)"
  LE_ENABLED="$(get_env LETSENCRYPT_ENABLED)"
  LE_EMAIL="$(get_env LETSENCRYPT_EMAIL)"
  TRAEFIK_PROTOCOL="$(get_env TRAEFIK_PROTOCOL)"
  if [[ -z "$ROOT_URL" || "$ROOT_URL" != https://* || "$ROOT_URL" == *localhost* ]]; then
    echo 'ERROR: --production requires ROOT_URL=https://your-real-domain in server/.env.' >&2
    exit 13
  fi
  if [[ -z "$DOMAIN" || "$DOMAIN" == localhost || "$DOMAIN" == *example* ]]; then
    echo 'ERROR: --production requires DOMAIN set to the real public DNS name.' >&2
    exit 14
  fi
  if [[ "$LE_ENABLED" != true || "$TRAEFIK_PROTOCOL" != https || -z "$LE_EMAIL" ]]; then
    echo 'ERROR: set LETSENCRYPT_ENABLED=true, TRAEFIK_PROTOCOL=https, and a valid LETSENCRYPT_EMAIL for production.' >&2
    exit 15
  fi
fi

if [[ -d "$UPSTREAM_DIR/.git" ]]; then
  git -C "$UPSTREAM_DIR" pull --ff-only
else
  mkdir -p "$(dirname "$UPSTREAM_DIR")"
  git clone --depth 1 "$UPSTREAM_URL" "$UPSTREAM_DIR"
fi

cd "$UPSTREAM_DIR"
FILES=(-f compose.database.yml -f compose.yml -f compose.nats.yml -f docker.yml -f "$SERVER_DIR/compose.override.yml")
if [[ "$PROFILE" == production ]]; then
  FILES=(-f compose.monitoring.yml -f compose.traefik.yml -f compose.database.yml -f compose.yml -f compose.nats.yml -f docker.yml -f "$SERVER_DIR/compose.override.yml")
fi

echo 'Validating merged Compose configuration...'
docker compose --env-file "$ENV_FILE" "${FILES[@]}" config --quiet
echo 'Starting the official Rocket.Chat stack...'
docker compose --env-file "$ENV_FILE" "${FILES[@]}" up -d
printf '\nStack started. Check status with:\n  cd %q && docker compose --env-file %q %s ps\n' "$UPSTREAM_DIR" "$ENV_FILE" "${FILES[*]}"
if [[ "$PROFILE" == local ]]; then
  echo 'Local URL: http://localhost:3000 (complete the official first-run setup in the browser).'
else
  echo 'Production profile requested. Verify DNS, firewall, TLS issuance, health, backups, and administrator setup before announcing service availability.'
fi
