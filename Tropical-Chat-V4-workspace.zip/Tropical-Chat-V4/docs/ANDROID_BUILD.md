# Android client build and verification

## Upstream prerequisites

The official Rocket.Chat React Native contributing guide currently documents Node.js >= 22.14.0 and `pnpm` (version pinned in upstream `package.json`), and explicitly states that npm/yarn are not supported for this repository. Android Studio / Android SDK tooling is required for Android builds.

## Build commands (run inside the official source checkout)

Rocket.Chat’s official mobile white-label guide identifies the `single-server` branch as the starting point. It documents `app.json`, `app/lib/constants/colors.ts`, `android/gradle.properties`, `android/app/src/main/AndroidManifest.xml`, and `android/app/src/main/res/values/strings.xml` as white-label configuration points. The manifest `android:sharedUserId` must be changed to a unique app value before first release; changing it after release forces users to uninstall/reinstall. Official guide: https://developer.rocket.chat/docs/mobile-app-white-labelling and https://developer.rocket.chat/v1/docs/android-app-white-labeling.

After the upstream source has been fetched, apply the reviewed branding script and inspect its diff:

```bash
git clone -b single-server https://github.com/RocketChat/Rocket.Chat.ReactNative.git
cd Rocket.Chat.ReactNative
python3 /path/to/Tropical-Chat-V4/scripts/apply-mobile-branding.py \
  --repo "$PWD" --server-url https://your-real-rocketchat-domain.example
git diff -- app.json app/lib/constants/colors.ts android/gradle.properties \
  android/app/src/main/AndroidManifest.xml android/app/src/main/res/values/strings.xml
corepack enable
pnpm install
cd android
./gradlew assembleDebug
```

The script requires the real server URL; it refuses remote HTTP URLs and validates all expected settings before writing. It does not yet install the launcher/splash assets because the exact resource layout must be inspected in the checked-out branch first. To run on a connected emulator/device after configuring the app ID, use the upstream `pnpm android-whitelabel com.tropicalservers.chat` command documented by Rocket.Chat.

On Windows PowerShell, run `gradlew.bat assembleDebug` from the `android` directory. Verify the exact upstream branch's package scripts and Gradle tasks before using a release-specific command. The standard Gradle debug artifact path is typically `android/app/build/outputs/apk/debug/app-debug.apk`; do not copy it to `dist/android/` until it exists and has been inspected.

## Required artifact checks

```bash
# From repository root, after a successful build:
test -s android/app/build/outputs/apk/debug/app-debug.apk
apkanalyzer manifest application-id android/app/build/outputs/apk/debug/app-debug.apk
apksigner verify --verbose android/app/build/outputs/apk/debug/app-debug.apk
```

`apkanalyzer` and `apksigner` are Android SDK build-tools utilities; verify their availability. Copy the APK to `dist/android/` only after the checks succeed, and record the SHA-256 hash.

## Current environment result

The official white-label branch and paths have been researched from Rocket.Chat documentation, but no upstream React Native source checkout is present. `pnpm`, Gradle, ADB, and Android SDK environment variables were unavailable. The current Node.js is 22.16.0, which satisfies the documented minimum but is not sufficient by itself. A debug APK has **not** been built. The Android application ID and notification code have **not** been changed in upstream source.
