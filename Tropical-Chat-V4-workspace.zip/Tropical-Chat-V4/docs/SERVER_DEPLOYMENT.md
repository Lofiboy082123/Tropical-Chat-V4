# Tropical Chat server deployment

## Scope and version choice

This deploy helper fetches the official `RocketChat/rocketchat-compose` repository and applies a small Tropical Chat override rather than copying or rewriting the server backend. Research on 2026-10-25 identifies Rocket.Chat 8.9.0 as the current LTS release (published 2026-10-05, support through 2027-10-31). Rocket.Chat 8.x requires MongoDB 8.0 or later; the example pins MongoDB 8.2. Verify compatibility against the release metadata before changing either version.

Official deployment documentation recommends the official Compose repository, persistent database volumes, and Compose v2. The official stack includes the Rocket.Chat service, MongoDB, NATS, and optional Traefik/monitoring services. The override pins the app image tag and local root URL.

## Local-only startup

Prerequisites: Git, Docker Engine, Docker Compose v2, outbound access to GitHub and the container registry.

```bash
cp server/.env.example server/.env
# Review server/.env; keep BIND_IP=127.0.0.1 for local-only testing.
bash server/deploy.sh --local
```

The script clones or fast-forward updates the official compose repository into ignored `server/upstream/rocketchat-compose/`, validates the merged Compose model, and starts it. Local access is `http://localhost:3000`. Complete Rocket.Chat's real first-run administrator wizard in the browser. The script does not create fake users or preseed messages.

Useful commands (run from `server/upstream/rocketchat-compose`):

```bash
docker compose --env-file ../../.env ps
docker compose --env-file ../../.env logs --tail=200 rocketchat
```

Compose file paths used by the helper are the official files `compose.database.yml`, `compose.yml`, `compose.nats.yml`, and `docker.yml`; the production profile additionally uses `compose.monitoring.yml` and `compose.traefik.yml`.

## Production deployment

1. Provision a supported host and a DNS A/AAAA record pointing at it.
2. Set `ROOT_URL=https://your-real-domain.example` and `DOMAIN=your-real-domain.example` in `server/.env`; set `LETSENCRYPT_EMAIL` and `LETSENCRYPT_ENABLED` according to the current official `.env.example` and Traefik docs.
3. Confirm firewall rules, persistent storage, outbound access to Rocket.Chat Cloud/push services, and the HTTPS reverse proxy.
4. Run `bash server/deploy.sh --production`.
5. Verify DNS and certificate issuance, inspect `docker compose ps` and logs, finish admin setup, and test a second account exchanging real messages.

The production helper refuses `localhost` or a non-HTTPS `ROOT_URL`, but this is not a substitute for deployment review. Do not expose the raw port 3000 service directly to the internet. The production command and configuration have not been executed in this environment.

## Secrets

- `server/.env` is ignored by Git and set to mode 0600 when the helper creates it.
- Keep registration tokens and any external provider credentials out of source control.
- Use your deployment platform's secret manager for production secrets where possible.
- The official first-run setup creates the real administrator; use a unique password and MFA where supported.

## Persistence, backup, restore

The official Compose database file defines persistent MongoDB storage. Do not delete volumes when stopping the stack. Back up to a protected destination:

```bash
bash server/backup.sh
```

Restore requires an explicit typed confirmation because `--drop` can replace documents:

```bash
bash server/restore.sh server/backups/tropical-chat-YYYYMMDDTHHMMSSZ.archive
```

A backup is not validated until restored into a separate test instance and checked. Copy backups off-host, encrypt them at rest, restrict access, and define retention. This workspace has not executed these scripts against a running MongoDB instance.

## Start, stop, upgrade, recovery

Use the same Compose files/profile that was used for deployment. The helper clones upstream to a moving `main` checkout; before production changes, record the exact upstream commit and review it. For an upgrade, back up first, verify the target Rocket.Chat/MongoDB compatibility matrix, change `RELEASE` and `MONGODB_VERSION` intentionally, then pull and recreate the services with the same Compose file set. Never downgrade MongoDB data files to older binaries without following MongoDB's documented downgrade procedure.

Stop without deleting persistent volumes:

```bash
cd server/upstream/rocketchat-compose
docker compose --env-file ../../.env -f compose.database.yml -f compose.yml -f compose.nats.yml -f docker.yml -f ../../compose.override.yml stop
```

To recover, inspect `docker compose ps` and logs, check database readiness and disk space, and restore only after diagnosing the failure. Do not use `docker compose down -v` unless intentionally destroying all stored workspace data.
