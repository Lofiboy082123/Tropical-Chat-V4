# Tropical Chat Starlight notifications

Required title: **Tropical Chat Starlight Message Incoming**.

## Current implementation status

Starlight has not yet been implemented in the upstream clients. The official Android React Native and Electron source trees were not available in the inspected workspace, and GitHub clone attempts failed due to DNS/network restrictions. This document defines the integration constraints; it is not a claim that notifications have been changed.

## Android integration constraints

- Reuse the official Rocket.Chat push-notification pipeline and its server/provider configuration. A client-only change cannot make remote push work without the server-side provider configuration and credentials.
- Use Android's real notification APIs and upstream notification channel/permission handling; preserve notification deep links and open the matching room/thread using existing routing.
- Change the displayed title only at the notification presentation layer. Keep actual message body tied to the incoming event, and honor the user's preview/privacy settings.
- Exclude the current user's own messages, honor muted rooms, and avoid duplicate notifications when foreground socket events and push events refer to the same message.
- Test Android 13+ notification permission denial/grant, channel settings, background, force-stopped/terminated behavior, offline reconnect, and tap-through navigation on real devices.

## Electron integration constraints

- Use the official Electron notification abstraction and OS-native notification APIs already used by the upstream app; do not add a parallel polling or fake-message system.
- Use the same exact title for genuine incoming messages only. Body previews must respect the existing privacy setting. Clicking must use the upstream notification routing mechanism for the correct room.
- Validate behavior on Windows 10/11 and a supported Linux desktop session; notification services vary by desktop environment.

## Acceptance tests

1. Incoming message from a different account produces one notification with the exact title.
2. Body preview contains the real message only when previews are enabled.
3. Own messages do not notify the sender.
4. Muted conversations and disabled notifications stay silent.
5. A message received while foregrounded does not duplicate the push notification.
6. Notification tap opens the correct conversation where supported.
7. No notification claims remote push works unless provider configuration is valid and end-to-end tested.

Implementation is blocked on obtaining and checking out the official upstream source. Once available, these changes should be made as a focused patch and run through upstream tests rather than implemented in a separate chat application.
