# Desktop client customization and build

The official Rocket.Chat Electron repository documents Windows 10+, Linux Ubuntu 22.04+ (x64), and macOS 12+ packaging. Its current development guide requires Node.js >= 24.11.1 and Yarn >= 4.0.2. The current environment's Node.js 22.16.0 and missing Yarn do not meet that toolchain.

The official Electron app supports a bundled `servers.json` file for seeding a server connection. Generate one after the actual server URL is chosen:

```bash
TROPICAL_CHAT_SERVER_URL=https://chat.your-domain.example node desktop/generate-config.mjs /path/to/Rocket.Chat.Electron/servers.json
```

From the official Electron repository, follow that branch's instructions (`yarn`, `yarn start` for development; `yarn release` to package on the current operating system). Windows installer generation should run on a supported Windows runner. Linux packages should be built on a supported Linux runner and verified for architecture and package format.

No Electron source checkout is present in the current workspace, so the app name, icon, native notification title, package identity, and upstream packaging configuration have not been changed. No Windows installer or Linux package was built. Do not report the config generator as a finished white-label client.
